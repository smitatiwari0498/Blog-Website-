import React from 'react'

const header = () => {
  return (
    <div>
      <nav>
        <h1>Header</h1>
        <ul>
          <li>Home</li>
          <li>About</li>
          <li>Contact</li>
        </ul>
        <img src="https://via.placeholder.com/50" alt="Logo" />
      </nav>
    </div>
  )
}

export default header
