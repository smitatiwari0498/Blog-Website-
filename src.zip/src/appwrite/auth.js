/* eslint-disable no-unused-vars */
/* eslint-disable no-useless-catch */
import { Client, Account, ID } from "appwrite";
import conf from "../conf/conf";

export class AuthService {
  client = new Client();
  account;

  constructor() {
    this.client
      .setEndpoint(conf.appwriteUrl)
      .setProject(conf.appwriteProjectId);

    this.account = new Account(this.client);
  }

  // Create account and auto login
  async createAccount({ email, password, name }) {
    try {
      const user = await this.account.create(
        ID.unique(),
        email,
        password,
        name
      );

      if (user) {
        return this.login({ email, password });
      }

      return user;
    } catch (error) {
      throw error;
    }
  }

  // Login user
  async login({ email, password }) {
    try {
      return await this.account.createEmailSession(email, password);
    } catch (error) {
      throw error;
    }
  }

  // Get current user (FIXED)
  async getCurrentUser() {
  try {
    return await this.account.get();
  } catch (error) {
    if (error.code === 401) {
      return null; 
    }
    throw error; 
  }
}

  // Logout user
  async logout() {
    try {
      await this.account.deleteSessions("current");
    } catch (error) {
      throw error;
    }
  }
}

const authService = new AuthService();
export default authService;